<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
</head>
<body>
<style>
		body {
			height: 100%;
			width: 100%;
			background-image: url('display.jpg');
			background-size: cover;
			background-position: center;
		}
	</style>



<div class="container">
    <a href="user.php" class="btn btn-primary my-5 text-light">Add Link</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">URL</th>
            <th scope="col">Option</th>
        </tr>
        </thead>
        <tbody>
        <?php
           $sql = "SELECT * FROM saved_links";
           $result = mysqli_query($conn, $sql);
           if ($result) {
            while( $row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $url=$row['url'];
            echo '
            <tr>
            <th scope="row">'.$id.'</th>
            <td>'.$url.'</td>
            <td>
            <button><a href="update.php?updateid='.$id.'">Update</a></button>
            <button><a href="delete.php?deleteid='.$id.'">Delete</a></button>
           </td>
            </tr>';
           }
            }
         else {
            echo "<tr><td colspan='3'>No links found.</td></tr>";
        }
        ?>
        <td>
        
        </tbody>
    </table>
</div>
</body>
</html>
