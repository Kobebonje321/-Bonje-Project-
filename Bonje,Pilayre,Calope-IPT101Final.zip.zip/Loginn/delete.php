<?php
include 'connect.php';
if(isset($_GET['deleteid']))
{
    $id=$_GET['deleteid'];

    // Display a confirmation prompt
    echo "<script>
            var confirmDelete = confirm('Are you sure you want to delete this item?');
            if (!confirmDelete) {
                window.location.href='display.php'; // Redirect back to the display page
            }
          </script>";

    // If user confirms deletion, proceed with deleting the item
    $sql="DELETE FROM saved_links WHERE id=$id";
    $result=mysqli_query($conn,$sql);

    if($result){
        //echo "Deleted Successfully";
        header('location:display.php');
    }
}
?>