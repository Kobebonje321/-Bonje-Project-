<?php
$sname = "localhost";
$uname = "root";
$password = "";
$dbname = "link";

// Create connection
$conn = new mysqli($sname, $uname, $password, $dbname);

?>