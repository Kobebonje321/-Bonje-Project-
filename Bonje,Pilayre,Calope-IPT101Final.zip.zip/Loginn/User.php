<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $url = $_POST['url'];
  
    $sql = "INSERT INTO `saved_links` (`url` ) VALUES ('$url')"; // changed column order to match database table
    $result=mysqli_query($conn,$sql);
    if($result){
        //echo "Data saved successfully";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
   
  </head>
  <body>
  <style>
		body {
			height: 100%;
			width: 100%;
			background-image: url('display.jpg');
			background-size: cover;
			background-position: center;
		}
	</style>
    <div class="container">
        <form method="post">
            <div class="form-group">
                <br><br> <label for="exampleInputURL">URL You Want To Save</label><br><br>
                <input type="text" class="form-control" id="exampleInputURL" name="url" placeholder="Enter link">
         
          
            <br><button type="submit" name="submit" class="btn btn-primary">Submit</button><br>
           <br> <br> <a href="home.php" class="ca">Back</a><br><br>
            <br> <a href="display.php" class="ca">Links</a><br>

        </form>
    </div>
  </body>
</html>
